#ifndef PRINT
#define PRINT

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Struct.h"

void PrintList(FIX_DATA *start, char *name);
void PrintListInBynary(FIX_DATA *start, char *name);

#endif