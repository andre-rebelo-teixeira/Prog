#ifndef READER
#define READER

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Struct.h"

FIX_DATA *readerSelector(char continent[], FIX_DATA *newData);

#endif