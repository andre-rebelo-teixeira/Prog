#ifndef USERINPUT
#define USERINPUT

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "auxiliar.h"

void treatUserInput(int argc, char *argv[], int *array, char *nameInput, char *nameOutput, char *continent);

#endif